Configuration and approach for implementing complete project

Web.xml:

 — dispatcher servlet configuration , url pattern </rest>

Spring-servlet.xml

Bean tags of all controllers with bean id

HTML — 

New User :  registerUser.html

Exiting user : existingUser.html

ANGULAR —

App.js :

Var app = angular.module(“TIMECLOCK”, [dependencies])

App.route(“/path/registerUser.html”, ../../js/registerUser.js)
App.route(“/path/existingUser.html”, ../../js/existingUser.js)


JS File —

registerUser.js

App.controller(“registerUser”, function($scope){


$http.post(/rest/registerUser, data, config).then(function (response) {
// This function handles success
}, function (response) {
// this function handles error
});
})

Controller —

@controller registerUserController
@requestMapping(‘/registerUser’)
Public class registerUserController (inputargs){

Input parmeters --userid , pwd encryption to be handled 
registerUserservice rs = new registerUserservice;

rs.newUserRegistration(inputargs);
}

Service —

@service
public class registerUserservice {


Public newUserRegistration(inputargs){
//Business logic 

registerUserDAO new = new registerUserDAO;

New.newUserRegistrationDAO(inputargs);
}
}

DAO—

@repository 
public class registerUserDAO {

Public newUserRegistrationDAO(inputargs){

//DB Connection
//Executing query -- saving new user details
//Returning result
}
