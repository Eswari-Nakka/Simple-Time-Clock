/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timeclock;

import timeclock.utilities.Debugger;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import timeclock.crypto.PassEncryptor;
import timeclock.data.DbConnection;
import timeclock.objects.Employee;
import timeclock.utilities.AppSettings;
import timeclock.utilities.DateUtils;
import timeclock.workers.AddEmployeeWorker;
import timeclock.workers.ClockInWorker;
import timeclock.workers.ClockOutWorker;
import timeclock.workers.CreateReportWorker;
import timeclock.workers.DeleteEmployeeWorker;
import timeclock.workers.EditEmployeeWorker;
import timeclock.workers.EmployeeTimeReportWorker;
import timeclock.workers.ListEmployeesWorker;
import timeclock.workers.WhoIsClockedInWorker;

/**
 * This is the main GUI for the app.
 *
 * @author eswarinakka
 */
public class TimeClock extends JFrame {
    
    private String ADMIN_PASS;

    private ArrayList<Employee> EmpNames;
    private Employee empSelectedEmployee;
    private String strSelectedEmployee;
    private JComboBox cboEmpList;
    private Timer timer;

    
    

   
    public void addEmployeeToList(Employee emp) {
        // Add to ArrayList and Add to cboEmpList
        EmpNames.add(emp);

        // Sort the list
        Collections.sort(EmpNames);

        // Add all Employees to list
        for (Employee aEmp : EmpNames) {
            cboEmpList.addItem(aEmp);
        }

        // Set to first name in list
        cboEmpList.setSelectedIndex(0);
    }

    /**
     * Deletes the employee from the list.
     *
     * @param emp
     */
    public void deleteEmployeeFromList(Employee emp) {
        int empIndex = 0;
        boolean found = false;
        while (empIndex < EmpNames.size() && found == false) {
            if (EmpNames.get(empIndex).getEmployeeID() == emp.getEmployeeID()) {
                Debugger.log("Deleted Employee " + EmpNames.get(empIndex).toString());
                EmpNames.remove(empIndex);
                found = true;
            }
            empIndex++;
        }

        // Add the Employee list to the combobox
        for (Employee aEmp : EmpNames) {
            cboEmpList.addItem(aEmp);
        }

        empSelectedEmployee = EmpNames.get(0);
        strSelectedEmployee = empSelectedEmployee.getFirstName();
    }

    /**
     * Updates the employees in the list.
     *
     * @param emp
     */
    public void updateEmployeeInfoInList(Employee emp) {
        int empIndex = 0;
        boolean found = false;
        while (empIndex < EmpNames.size() && found == false) {
            if (EmpNames.get(empIndex).getEmployeeID() == emp.getEmployeeID()) {
                emp.setClockedIn(EmpNames.get(empIndex).getIsClockedIn_bool());
                EmpNames.set(empIndex, emp);
                found = true;
            }
            empIndex++;
        }

        // Sort the list
        Collections.sort(EmpNames);

        // Add the Employee list to the combobox
        for (Employee aEmp : EmpNames) {
            cboEmpList.addItem(aEmp);
        }

        empSelectedEmployee = emp;
        strSelectedEmployee = empSelectedEmployee.getFirstName();
    }

    /**
     * Updates the clock status for the employee list.
     *
     * @param emp
     * @param in
     */
    public void clockEmployee(Employee emp, boolean in) {
        int empIndex = 0;
        boolean found = false;
        while (empIndex < EmpNames.size() && found == false) {
            if (EmpNames.get(empIndex).getEmployeeID() == emp.getEmployeeID()) {
                EmpNames.get(empIndex).setClockedIn(in);
                found = true;
            }
            empIndex++;
        }
    }

    /**
     * Method to stop clock and shutdown the database.
     */
    private void shutDown() {
        this.timer.stop();
        DbConnection.shutdownDerby();
    }

    /**
     * Validate the users password, and also validate if user has admin 
     * privileges.
     * @param pass the entered password
     * @param admin if admin privileges is required
     * @return 
     */
    private boolean validatePassword(String pass,boolean admin)
    {
        // User hit cancel
        if (pass == null) {
            return false;
        }            
        // Password encryption
        PassEncryptor passEn = new PassEncryptor();
        /* If admin privilege not required, just check that the employee 
         * and pass are a match */
        if(!admin)
            return passEn.checkPassword(pass,empSelectedEmployee.getPassword());
        else
        {
            /* If admin is required, check that selected employee has admin
             * privileges and the pass is a match or check if the master password
             * was entered as an override */
            boolean isAdmin = empSelectedEmployee.getIsAdmin_bool();
            boolean isPassMatch = passEn.checkPassword(pass,empSelectedEmployee.getPassword());
            boolean isMasterPass = passEn.checkPassword(pass, this.ADMIN_PASS);
            return (isAdmin && isPassMatch)|| isMasterPass;
            // Uncomment to bypass password
            //return true;
        }
    }
}
