package com.spring.mvc.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.github.javafaker.Faker;
import com.spring.mvc.component.Employee;

import timeclock.data.DbConnection;
import timeclock.data.DbStatements;



@Repository
public class EmployeeDaoImpl {

	// Method to generate the dummy employee records.
	public List<Employee> getAllEmployeesFromDb(int empID) {

		// To generate the fake details for the employees.
		Faker faker = new Faker();

		// Employee list.
		List<Employee> employeelist = new ArrayList<Employee>();

		 // Get the database connection
        Connection conn = null;
        PreparedStatement getEmp = null;
        ResultSet rs = null;
        Employee resultEmp = null;
        
        try{       
               conn = DbConnection.establishConnection();
               getEmp = conn.prepareStatement(DbStatements.GET_EMPLOYEE_BY_ID);
               getEmp.setInt(1, empID );
               rs = getEmp.executeQuery();
               
               while(rs.next())
               {
                   int id = rs.getInt(DbStatements.EMP_COLUMNS[0]);
                   String first = rs.getString(DbStatements.EMP_COLUMNS[1]);
                   String last = rs.getString(DbStatements.EMP_COLUMNS[2]);
                   int salary = rs.getInt(DbStatements.EMP_COLUMNS[3]);
                   int admin = rs.getInt(DbStatements.EMP_COLUMNS[4]);
                   String pass = rs.getString(DbStatements.EMP_COLUMNS[5]);
                   int status = rs.getInt(DbStatements.EMP_COLUMNS[6]);
                   resultEmp = new Employee(id,first,last,salary,admin,pass,status);
               }
        }
        catch (SQLException ex)
        { 
           // Debugger.log("Unable to add Employee: ");
        }finally
        {
//            DbUtils.closeQuietly(rs);
//            DbUtils.closeQuietly(getEmp);
//            DbUtils.closeQuietly(conn);
//            return resultEmp;
        }
		return employeelist;
}
}