sampleApp.controller('loginController', ["$compile", "$scope", "$window", "myCommonHelper", "$filter",  
    function ($rootScope, $scope) {  
      
      $scope.loginUser = function () { 
      username = emp.usnm; 
       password =emp.psw;
       $http({ method: 'GET',url: '/loginUser',emp}).then(function successCallback(data) {
    // this callback will be called asynchronously
    // when the response is available
    
       
      
      }, function errorCallback(data) {
    // called asynchronously if an error occurs
    // or server returns response with an error status.
        }); 
        
          };  
      
}]); 
    