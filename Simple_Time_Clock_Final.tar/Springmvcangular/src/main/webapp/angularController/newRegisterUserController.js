sampleApp.controller('newRegisterController', ["$compile", "$scope", "$window", "myCommonHelper", "$filter",  
    function ($rootScope, $scope) {  
      
      $scope.newUserRegistration = function () {  
       $http({ method: 'GET',url: '/registerUser'}).then(function successCallback(data) {
    // this callback will be called asynchronously
    // when the response is available
    
       
      }, function errorCallback(data) {
    // called asynchronously if an error occurs
    // or server returns response with an error status.
        }); 
        
          };  
      
}]); 
    