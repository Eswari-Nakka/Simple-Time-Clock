(
function () {
    'use strict';
 
    angular
        .module('TimeClock', ['ngRoute', 'ngCookies'])
        .config(config)
        .run(run);
 
    config.$inject = ['$routeProvider', '$locationProvider'];
    function config($routeProvider, $locationProvider) {
        $routeProvider
        .when('/', {
                controller: 'LoginController',
                templateUrl: 'login.html'
                
            }).when('/Angular',{
            templateUrl : '/newRegisterUser.html',
            controller: 'newRegisterUserController'
        }).when('/Angular',{
            templateUrl : '/existingUser.html',
            controller: 'existingUserController'
        })
 
            .when('/home', {
                controller: 'HomeController',
                templateUrl: 'home.html'
            })            
            .when('/register', {
                controller: 'RegisterController',
                templateUrl: 'register.html',
                controllerAs: 'vm'
            })
            .otherwise({ redirectTo: '/login' });
    }    
    run.$inject = ['$rootScope'];
    
    function run(){
      console.clear();
    }
})();
    